package com.example.wiserrapps.data.model

data class riwayatkonsultasi (
    val id: Int,
    val nama:String,
    val online: String,
    val asal: String,
    val tanggal: String,
    val rate: Int,
    val photo: Int
)

data class populerkonsultasi (
    val id: Int,
    val nama:String,
    val online: String,
    val asal: String,
    val tanggal: String,
    val rate: Int,
    val photo: Int
)
