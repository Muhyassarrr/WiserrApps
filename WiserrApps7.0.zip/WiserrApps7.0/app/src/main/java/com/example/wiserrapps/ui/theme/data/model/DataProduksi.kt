package com.example.wiserrappsr.data.model

data class DataProduksi(
    val nama: String,
    val jumlah: Float
)