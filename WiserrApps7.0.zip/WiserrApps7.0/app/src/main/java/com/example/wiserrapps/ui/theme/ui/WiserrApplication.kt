package com.example.wiserrapps.ui.theme.ui

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class WiserrApplication: Application()