package com.example.wiserrapps.data.model

data class ProdukMangkok(
    val nama: String,
    val tanggal: String,
    val harga: String,
    val berat: String,
    val imageRes: Int
)

data class ProdukPatahan(
    val nama: String,
    val tanggal: String,
    val harga: String,
    val berat: String,
    val imageRes: Int
)
data class ProdukSudut(
    val nama: String,
    val tanggal: String,
    val harga: String,
    val berat: String,
    val imageRes: Int
)
data class ProdukOval(
    val nama: String,
    val tanggal: String,
    val harga: String,
    val berat: String,
    val imageRes: Int
)
