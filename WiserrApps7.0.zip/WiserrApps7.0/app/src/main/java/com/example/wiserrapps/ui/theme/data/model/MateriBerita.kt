package com.example.newappwiser.model

data class MateriBerita(
    val id: Int,
    val title: String,
    val description: String,
    val imageRes: Int
)