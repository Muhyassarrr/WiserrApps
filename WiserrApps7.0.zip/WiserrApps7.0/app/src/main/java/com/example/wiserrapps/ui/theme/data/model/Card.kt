package com.example.wiserrapps.data.model

import androidx.compose.ui.graphics.Color

data class Card(
    val name: String,
    val color: Color
)
