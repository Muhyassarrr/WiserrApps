package com.example.wiserrapps.data.model

data class Berita(
    val id: Int,
    val judul: String,
    val photo: Int,
    val sumber: String,
    val pembuat: String,
    val tanggal:String,
    val isi : String,
    val headline: String
)
