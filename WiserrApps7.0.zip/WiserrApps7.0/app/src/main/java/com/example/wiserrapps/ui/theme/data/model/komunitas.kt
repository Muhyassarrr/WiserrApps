package com.example.wiserrapps.data.model

data class komunitas (
    val title: String,
    val memberCount: String,
    val imageRes: Int
)