package com.example.wiserrapps.ui.screen.edukasi


import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.wiserrapps.ui.screen.edukasi.component.VideoItem
import com.example.wiserrapps.data.DataArtikel
import com.example.wiserrapps.data.DataBerita
import com.example.wiserrapps.data.DataVideo
import com.example.wiserrapps.data.model.Artikel
import com.example.wiserrapps.data.model.Berita
import com.example.wiserrapps.data.model.video
import com.example.wiserrapps.ui.navigation.Screen
import com.example.wiserrapps.ui.screen.edukasi.component.ArtikelItem
import com.example.wiserrapps.ui.screen.edukasi.component.BeritaItem
import com.example.wiserrapps.ui.screen.edukasi.component.EdukasiTopBar


@Composable
fun EdukasiScreen(
    navController: NavController,
    berita:List<Berita> = DataBerita.berita,
    video: List<video> = DataVideo.Video,
    artikel: List<Artikel> = DataArtikel.artikel
){
    Column(
        modifier = Modifier
            .padding(horizontal = 15.dp)
    ) {
        EdukasiTopBar()
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(0.dp),
        ) {
            item {
                Text(
                    text = "Berita",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                LazyRow(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(15.dp)
                ) {
                    items(berita, key = {it.id}){
                        BeritaItem(berita = it) { beritaId ->
                            navController.navigate(Screen.detailberita.route + "/$beritaId")
                        }
                    }
                }
            }
            item {
                Text(
                    text = "Video",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                LazyRow(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(video, key = {it.id}) {
                        VideoItem(video = it) { videoId ->
                            navController.navigate(Screen.detailvideo.route + "/$videoId")
                        }
                    }
                }
            }
            item {
                Text(
                    text = "Artikel",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            items(artikel, key = {it.id}){
                ArtikelItem(artikel = it) { artikelId ->
                        navController.navigate(Screen.detailartikel.route + "/$artikelId")
                    }
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun EdukasiScreenPreview(){
    val navController = rememberNavController()
    EdukasiScreen(navController)
}

