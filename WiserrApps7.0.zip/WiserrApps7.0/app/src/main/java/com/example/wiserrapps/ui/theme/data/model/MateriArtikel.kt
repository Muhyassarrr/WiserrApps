package com.example.newappwiser.model

data class MateriArtikel(
    val id: Int,
    val title: String,
    val description: String,
    val imageRes: Int
)