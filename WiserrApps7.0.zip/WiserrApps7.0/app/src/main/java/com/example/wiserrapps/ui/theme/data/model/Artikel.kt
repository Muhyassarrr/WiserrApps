package com.example.wiserrapps.data.model

data class Artikel(
    val id: Int,
    val judul: String,
    val isi: String,
    val deskripsi: String,
    val sumber: String,
    val photo: Int
)
