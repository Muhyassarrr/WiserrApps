package com.example.wiserrapps.ui.theme.data.model

data class videoyt(
    val id: Int,
    val judul: String,
    val deskripsi: String,
    val photo: Int
)
