package com.example.wiserrapps.data.model

data class video(
    val id: Int,
    val judul: String,
    val deskripsi: String,
    val photo: Int
)
