package com.example.wiserrapps.data

import com.example.wiserrapps.R
import com.example.wiserrapps.data.model.Profiles

object DataProfile {
    val profileuser = listOf(
        Profiles(
            id = 1,
            nama = "Brian Domani",
            nickname = "Brian",
            photo = R.drawable.ftbrian1
        ),
    )
}