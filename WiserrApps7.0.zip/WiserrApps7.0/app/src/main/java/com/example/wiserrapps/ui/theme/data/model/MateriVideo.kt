package com.example.newappwiser.model

data class MateriVideo(
    val id: Int,
    val title: String,
    val description: String,
    val imageRes: Int
)