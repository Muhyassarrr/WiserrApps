package com.example.wiserrapps.data.model

data class Profiles(
    val id: Int,
    val nama: String,
    val nickname: String,
    val photo: Int
 )
